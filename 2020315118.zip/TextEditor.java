import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;

public class TextEditor extends JFrame  {
	// Frame
	JTextArea t;
	JFrame f;
	
	
	//Text Editor
	TextEditor(){
		f = new JFrame("editor");
		t = new JTextArea();
		
		JMenuBar  menuBar = new JMenuBar();
		//File section
		JMenu fileList = new JMenu("File");
		JMenuItem newitem = new JMenuItem("New");
		JMenuItem openitem = new JMenuItem("Open");
		JMenuItem saveitem = new JMenuItem("Save");
		JMenuItem printitem = new JMenuItem("Print");
		fileList.add(newitem);
		fileList.add(openitem);
		fileList.add(saveitem);
		fileList.add(printitem);
		menuBar.add(fileList);
		
		// Edit section
        JMenu editList = new JMenu("Edit");
        JMenuItem cutitem = new JMenuItem("Cut");
        JMenuItem copyitem = new JMenuItem("Copy");
        JMenuItem pasteitem = new JMenuItem("Paste");
        editList.add(cutitem);
        editList.add(copyitem);
        editList.add(pasteitem);
        menuBar.add(editList);

        // Close section
        JMenu closeList = new JMenu("Close");
        JMenuItem closeitem = new JMenuItem("Close");
        closeList.add(closeitem);
        menuBar.add(closeList);
		
		
		
        newitem.setActionCommand("NewFile");
		newitem.addActionListener(new ButtonClickListener());
		openitem.setActionCommand("OpenFile");
		openitem.addActionListener(new ButtonClickListener());
		saveitem.setActionCommand("SaveFile");
		saveitem.addActionListener(new ButtonClickListener());
		cutitem.setActionCommand("Cut");
		cutitem.addActionListener(new ButtonClickListener());
		copyitem.setActionCommand("Copy");
		copyitem.addActionListener(new ButtonClickListener());
		pasteitem.setActionCommand("Paste");
		pasteitem.addActionListener(new ButtonClickListener());
		closeitem.setActionCommand("Close");
		closeitem.addActionListener(new ButtonClickListener());
		
		
		/* impl : write code for menubar with buttons */
		f.setJMenuBar(menuBar);
		f.add(t);
		f.setSize(1000,1000);
		f.show();
		
	}
	
	public static void main(String args[]) {
		TextEditor myTextEditor = new TextEditor();
	}

	class ButtonClickListener implements ActionListener {
		public void createTheFile() {
			try {
				t.setText("");            	
            }
            catch (Exception evt) {
                JOptionPane.showMessageDialog(f, evt.getMessage());
            }
		}
		public void openTheFile() {

			JFileChooser j = new JFileChooser("f:");
	        int r = j.showOpenDialog(null);

	        // If the user selects a file
	        if (r == JFileChooser.APPROVE_OPTION) {
	            // Set the label to the path of the selected directory
	            File fi = new File(j.getSelectedFile().getAbsolutePath());

	            try {
	            	/* impl : Read File("fi") and write it on text area using setText */
	            	BufferedReader reader = new BufferedReader(new FileReader(fi));
	                StringBuilder sb = new StringBuilder();
	                String line;

	                while ((line = reader.readLine()) != null) {
	                    sb.append(line).append("\n");
	                }

	                // Assuming you have a JTextArea variable named "textArea" to display the file contents
	                t.setText(sb.toString());

	                reader.close();
	            	
	            }
	            catch (Exception evt) {
	                JOptionPane.showMessageDialog(f, evt.getMessage());
	            }
	        }
	        // If the user cancelled the operation
	        else
	            JOptionPane.showMessageDialog(f, "the user cancelled the operation");
		}
		
		public void saveTheFile() {
			JFileChooser j = new JFileChooser("f:");
			int r = j.showSaveDialog(null);
			
			if (r == JFileChooser.APPROVE_OPTION) {
				File fi = new File(j.getSelectedFile().getAbsoluteFile().toString());
				try {
					 FileWriter wr = new FileWriter(fi, false);
	                    BufferedWriter w = new BufferedWriter(wr);
	                    w.write(t.getText());

	                    w.flush();
	                    w.close();
				}catch(Exception evt) {
					JOptionPane.showMessageDialog(f, evt.getMessage());
				}
			}
	        // If the user cancelled the operation
			else {
				JOptionPane.showMessageDialog(f, "Operation has been cancelled");
			}
		}
		public void printTheFile() {
			try {
				t.print();
            }
            catch (Exception evt) {
                JOptionPane.showMessageDialog(f, evt.getMessage());
            }
		}
		//made by myself vvvv
		public void cutTheFile() {
			try {
            	t.cut();
			}catch(Exception evt) {
				JOptionPane.showMessageDialog(f, evt.getMessage());
			}
		
		}
		public void copyTheFile() {
			try {
				t.copy();		        
           	}catch(Exception evt) {
				JOptionPane.showMessageDialog(f, evt.getMessage());
			}
		
		}
		
		public void pasteTheFile() {
	        try {
	        	t.paste();	        
           	}catch(Exception evt) {
				JOptionPane.showMessageDialog(f, evt.getMessage());
			}
		
		}
		public void closeTheFile() {
		    try {
		        f.show(false);
		        System.exit(0);
		    } catch (Exception evt) {
		    	JOptionPane.showMessageDialog(f, evt.getMessage());
		    }
		}

		@Override
		public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			String s = e.getActionCommand();
			
			/* impl : Write proper code for each action command */
			/* Hint : use above saveTheFile, openTheFile function and below reference page's functions.
			 * JTextarea inherit JTextComponent! you can use below functions!!
			 * https://docs.oracle.com/javase/7/docs/api/javax/swing/text/JTextComponent.html
			 * cut(), copy(), paste(), getText(), setText() etc.
			 */
			if(s.equals("NewFile"))
				createTheFile();
			else if(s.equals("OpenFile")) {
				openTheFile();
			}
			else if(s.equals("SaveFile")) 
				saveTheFile();
			else if(s.equals("Print"))
				printTheFile();
			else if(s.equals("Cut")) 
				cutTheFile();
			else if(s.equals("Copy")) 
				copyTheFile();
			else if(s.equals("Paste")) 
				pasteTheFile();
			else if(s.equals("Close")) 
				closeTheFile();
			
			/* impl : Write proper code for each action command */
			
			
			
		}

		
	}

	

}