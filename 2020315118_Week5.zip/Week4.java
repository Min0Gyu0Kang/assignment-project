import java.util.Random;
import java.util.Scanner;

class Course{
	String Name;
	int Grade;
	int Limit;
	Boolean registered;	
}
class College{
	Random random;
	Course[] courseArray;
	
	College() {
	Random random;
	//public Course(){
	random = new Random();
	//.Grade=random.nextInt(3)+1;.Limit=random.nextInt(2);.registered = false;}
	
	courseArray = new Course[4]; 
	for(int i=0;i<4;i++) {
		courseArray[i]=new Course();
		}
	
	courseArray[0].Name="ENGLISH";courseArray[0].Grade=random.nextInt(4)+1;courseArray[0].Limit=random.nextInt(2);courseArray[0].registered = false;
	courseArray[1].Name="MATH";courseArray[1].Grade=random.nextInt(4)+1;courseArray[1].Limit=random.nextInt(2);courseArray[1].registered = false;
	courseArray[2].Name="KOREAN";courseArray[2].Grade=random.nextInt(4)+1;courseArray[2].Limit=random.nextInt(2);courseArray[2].registered = false;
	courseArray[3].Name="SCIENCE";courseArray[3].Grade=random.nextInt(4)+1;courseArray[3].Limit=random.nextInt(2);courseArray[3].registered = false;
	}
	int register(String courseName, int grade) {
		
		//System.out.println(courseName);
		for(int i=0;i<4;i++){ //name > grade > limit > register
			if (courseName.equals(courseArray[i].Name)) {//name
				if(grade == courseArray[i].Grade ) { //grade
					if(courseArray[i].Limit==0) { //limit
						if(courseArray[i].registered==false){ //register
							courseArray[i].registered=true;
							System.out.println("Register success");
							return 1;
						}
						else {
							System.out.println("Register error: already registered");
							return -1;
						}
					}
					else {
						System.out.println("Register error: register capacity exceeded");
						return -1;
					}
					
				}
				else {
					System.out.println("Register error: unapplicable grade");
					return -1;
				}
			}
			else{
				System.out.println("Register error: nonexistent course");
				return -1;
			}
		}
		return 1;
	}
	
	int withdraw(String courseName) {
		for(int i=0;i<4;i++){ //name > register
			if(courseName.equals(courseArray[i].Name)) {
				if(courseArray[i].registered==false) {
					System.out.println("Withdraw error: nonregistered course");
					return -1;
				}
				else {
					courseArray[i].registered = false;
					System.out.println("Withdraw success");
					return 1;
				}
			}
			else {
				System.out.println("Withdraw error: nonexistent course");
				return -1;
			}
		}
		return 1;
		
	}
	
}
//Return nonnegative integer if register or withdraw success, else return negative value (e.g., -1, -2, ...)
public class Week4 {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		College l= new College();
		
		System.out.println("ENGLISH-"+l.courseArray[0].Grade+"-"+l.courseArray[0].Limit+" MATH-"+l.courseArray[1].Grade+"-"+l.courseArray[1].Limit+" KOREAN-"+l.courseArray[2].Grade+"-"+l.courseArray[2].Limit+" SCIENCE-"+l.courseArray[3].Grade+"-"+l.courseArray[3].Limit); 
		//grade and course limit uses random
		System.out.println("Enter your grade");
		int grade = scn.nextInt();
		while(true) {
			System.out.println("Enter number (1:register),(2:withdraw),(3:finish)");
			int num = scn.nextInt();
			if(num==1||num==2) {
				System.out.println("Enter course name to register");
				String reg = scn.next();
				if(num==1) {
					l.register(reg, grade);
				}
				else if(num==2) {
					l.withdraw(reg);
				}
			}
			
			else{
				break;
			}
		}
		
	}
	
	
}
