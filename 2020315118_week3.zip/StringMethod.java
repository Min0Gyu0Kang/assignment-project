public class StringMethod {
// Returns the string created by adding 's2' after position 'index' of 's1'.
static String addString(String s1, int index, String s2) {
	s1=s1.substring(0,index+1) + s2 +s1.substring(index+1,s1.length());
	return s1;
	
}

// Returns reversed string of 's'
static String reverse(String s) {
	String temp="";
	for(int i=0;i<s.length();i++) {
		temp=temp+s.charAt(s.length()-(i+1));	
	}
	return temp;
	
}

// Returns a string with all 's2's removed from 's1'
static String removeString(String s1, String s2) {
	String temp="";
	String[] dd = s1.split(s2);
	
	for(String s: dd) {
		//System.out.print((s));
		temp += s;
		
	}
	return temp;
}

	/*
	 * abc-def-ghi-jkl abc def ghi jkl
	 */

public static void main(String[] args) {
	System.out.println(addString("0123456",3,"-")); //0123-456
	System.out.println(reverse("abc")); //cba
	System.out.println(removeString("01001000","00")); //0110
}
}
