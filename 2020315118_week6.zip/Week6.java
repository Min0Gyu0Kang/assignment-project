import java.util.Scanner;

class Food{ //Super
	String name;
	int calorie=0;
}

abstract class Noodle extends Food{
	int numNoodle=0; // number of noodle ordered
	public abstract String getNoodleName(); 
	public abstract int getNoodleCal();
	public abstract int getNoodleCnt();
	public abstract void order(int cnt);
}
abstract class Rice extends Food{
	int numRice=0; // number of rice ordered
	public abstract String getRiceName();
	public abstract int getRiceCal();
	public abstract int getRiceCnt();
	public abstract void order(int cnt);

}

class Ramen extends Noodle{
	Ramen(){
		name = "Ramen";
		calorie = 30;
	}
	
	public String getNoodleName() { //return name of food
		return name;
	}
	public int getNoodleCal() {
		return calorie;
	}
	public int getNoodleCnt() {
		return numNoodle;
	}
	public void order(int cnt) {//add cnt to the number of that food ordered
		numNoodle+=cnt;
	}
}
	
class Fried extends Rice{
	
	Fried(){
		name = "Fried";
		calorie = 20;
	}
	
	public String getRiceName() { //return name of food
		return name;
	}
	public int getRiceCal() {
		return calorie;
	}
	public int getRiceCnt() {
		return numRice;
	}
	public void order(int cnt) { //add cnt to the number of that food ordered
		numRice += cnt; 
	}
}

class Sushi extends Rice{
	Sushi(){
		name = "Sushi";
		calorie = 10;
	}
	public String getRiceName() { //return name of food
		return name;
	}
	public int getRiceCal() {
		return calorie;
	}
	public int getRiceCnt() {
		return numRice;
	}
	public void order(int cnt) {//add cnt to the number of that food ordered
		numRice += cnt;
	}
}

public class Week6 {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		Food fo = new Food();
		Food no = new Food();
		Food ri = new Food();
		Noodle ra = new Ramen();
		Rice fr = new Fried();
		Rice su = new Sushi();
		
		
		System.out.println("Menu: Ramen, Fried, Sushi");
		while(true) {
			System.out.println("Enter number (1: order), (2: check), (3: finish)");
			int num=scn.nextInt();
			if(num==1) { //order
				System.out.println("Enter food to order");
				String food=scn.next();
				if(food.equals(ra.name)) { //Noodle
					System.out.println("Enter Ramen count");
					int ramen=scn.nextInt();
					ra.order(ramen);
					System.out.println(ra.getNoodleCnt()+" Ramen(s) ordered successfully");
					System.out.println("Order success");
					
				}
				else if(food.equals(fr.name)) { //Rice
					System.out.println("Enter Fried count");
					int fried=scn.nextInt();
					fr.order(fried);
					System.out.println(fr.getRiceCnt()+" Fried(s) ordered successfully");
					System.out.println("Order success");
				}
				else if(food.equals(su.name)) { //Rice
					System.out.println("Enter Sushi count");
					int sushi=scn.nextInt();
					su.order(sushi);
					System.out.println(su.getRiceCnt()+" Sushi(s) ordered successfully");
					System.out.println("Order success");
				}
				else {
					System.out.println("Order error: nonexistent food");
				}
			}
			else if (num==2) { //check
				int calories=(ra.calorie*ra.getNoodleCnt())+(fr.calorie*fr.getRiceCnt())+(su.calorie*su.getRiceCnt());
				System.out.println("Ordered: Ramen-"+ ra.getNoodleCnt()+" Fried-"+fr.getRiceCnt()+" Sushi-"+su.getRiceCnt()+" /Total Calories: "+calories);
				System.out.println("Check success");
			}
			else {
				break;
			}

		}
				
	}

}
