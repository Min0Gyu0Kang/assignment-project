import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Week13 {
    static int[][] result;
    static int result_row, result_col;

    public static void main(String[] args) {
        try {
            // Read input from file
            Scanner scanner = new Scanner(new File("input.txt"));

            // Read dimensions of the first matrix
            int m = scanner.nextInt();
            int n = scanner.nextInt();

            int[][] matrix1 = new int[m][n];

            // Read elements of the first matrix
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n; j++) {
                    matrix1[i][j] = scanner.nextInt();
                }
            }

            // Read dimensions of the second matrix
            int p = scanner.nextInt();
            int q = scanner.nextInt();

            int[][] matrix2 = new int[p][q];

            // Read elements of the second matrix
            for (int i = 0; i < p; i++) {
                for (int j = 0; j < q; j++) {
                    matrix2[i][j] = scanner.nextInt();
                }
            }

            // Check if matrices can be multiplied
            if (n != p) {
                System.out.println("Matrices cannot be multiplied. Invalid dimensions.");
                return;
            }

            // Multiply matrices
            result_row = m;
            result_col = q;
            result = new int[result_row][result_col];

            // Create threads for matrix multiplication
            Thread[] threads = new Thread[result_row];
            for (int i = 0; i < result_row; i++) {
                threads[i] = new Thread(new MatrixMultiplication(matrix1, matrix2, i, result));
                threads[i].start();
            }

            // Wait for all threads to complete
            for (int i = 0; i < result_row; i++) {
                try {
                    threads[i].join();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            // Print the result matrix
            for (int i = 0; i < result_row; i++) {
                for (int j = 0; j < result_col; j++) {
                    System.out.print(result[i][j] + " ");
                }
                System.out.println();
            }

            // Compute the summary
            int summary = 0;
            for (int i = 0; i < result_row; i++) {
                for (int j = 0; j < result_col; j++) {
                    summary += result[i][j];
                }
            }

            // Print the summary
            System.out.println("Summary: " + summary);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}

class MatrixMultiplication implements Runnable {
    int[][] matrix1;
    int[][] matrix2;
    int row;
    int[][] result;

    public MatrixMultiplication(int[][] matrix1, int[][] matrix2, int row, int[][] result) {
        this.matrix1 = matrix1;
        this.matrix2 = matrix2;
        this.row = row;
        this.result = result;
    }

    @Override
    public void run() {
        for (int i = 0; i < matrix2[0].length; i++) {
            int temp = 0;
            for (int j = 0; j < matrix2.length; j++) {
                temp += matrix1[row][j] * matrix2[j][i];
            }
            result[row][i] = temp;
        }
    }
}
