import java.io.*;
import java.util.*;

public class readinput {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		try {
			InputStream fis = new FileInputStream("C:\\Users\\kmk\\eclipse-workspace\\week9\\src\\input.txt");
			InputStreamReader isr = new InputStreamReader(fis);
			BufferedReader br = new BufferedReader(isr);
			
			System.out.print("Enter word: ");
			String data = scan.next();
			String find;
			String look;
			int count=0;
			while((find = br.readLine()) != null) {
				look = find;
				//look should include all characters in one line of the file
				if(look.contains(data)) {
					count++;
				}
				
				
			}
			
			
			System.out.println("Total "+count+" of "+data+" is found in input.txt");
			br.close();isr.close();fis.close();
		}catch (IOException e) {e.printStackTrace();}
		

	}

}
