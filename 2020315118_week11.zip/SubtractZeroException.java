public class SubtractZeroException extends Exception {
    private int a;
	private int b;

	public SubtractZeroException(int a,int b) {
        this.a=a;
        this.b=b;
    }
}