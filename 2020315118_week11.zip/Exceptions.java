
public class Exceptions {
	String message;
	
    public void OutOfRangeException(int result) throws OutOfRangeException {
        if(result < 0 || result > 1000) {
            throw new OutOfRangeException(result);
        }
    }
    
    public void AddZeroException(int a, int b) throws AddZeroException {
        if(a == 0 || b == 0) {
            throw new AddZeroException(a,b);
        }
    }
    
    public void SubtractZeroException(int a, int b) throws SubtractZeroException {
        if(a==0||b == 0) {
            throw new SubtractZeroException(a,b);
        }
    }
}
