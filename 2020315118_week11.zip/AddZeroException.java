public class AddZeroException extends Exception {
	private int a;
	private int b;

	public AddZeroException(int a,int b) {
        this.a=a;
        this.b=b;
    }
}