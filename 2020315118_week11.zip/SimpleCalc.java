import java.util.*;

class SimpleCalculator{
	int result=0;
	public int add(int a,int b) throws AddZeroException{
		result = a+b;
		return result;
	}
	public int subtract(int a, int b) throws SubtractZeroException{
		result = a-b;
		return result;
	}
	public void print(int result) throws OutOfRangeException{
		System.out.println(result);
	}
	public int reset(int result) {
		result = 0;
		return result;
	}
	public int getResult(int result) {
		return result;
	}
	public void setResult(int result) {
		this.result = result;
	}
	
}


public class SimpleCalc {
	
	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		SimpleCalculator sc = new SimpleCalculator();
		Exceptions x = new Exceptions();
		int result=0;int a=0;int b=0;
		while(true) {
			System.out.print("Enter number (1:add)(2:subtract)(3:print)(4:reset)(5:exit) ");
			int num = scn.nextInt();
			if(num==1) { //add
					System.out.print("Enter a: ");
					a = scn.nextInt();
					System.out.print("Enter b: ");
					b = scn.nextInt();
					try {
						result = sc.add(a, b);
					} catch (AddZeroException e) {
						System.out.println("Add() is not allowed to subtract zero.");
						e.printStackTrace();
					}
					sc.setResult(result);
				
					
			}
			else if(num == 2) { //subtract
					System.out.print("Enter a: ");
					a = scn.nextInt();
					System.out.print("Enter b: ");
					b = scn.nextInt();
				try {
					result = sc.subtract(a, b);
				}catch(SubtractZeroException e) {
					System.out.println("Subtract() is not allowed to subtract zero.");
					e.printStackTrace();
				}
					sc.setResult(result);
				
			}
			else if (num == 3) { //print
				result = sc.getResult(result);
				try {
					sc.print(result);
				}catch(OutOfRangeException e) {
					System.out.println("Your result is out of range(0-1000).");
					e.printStackTrace();
				}
					
			}
			else if (num == 4) { //reset
				result = sc.reset(result);
				sc.setResult(result);
			}
			else {
				System.out.println("Terminated");
				break;
			}
		}
		scn.close();
	}

}
