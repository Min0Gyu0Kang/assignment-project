public class OutOfRangeException extends Exception {
    private int result;

	public OutOfRangeException(int result) {
        this.result =  result;
    }
}