#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Define the maximum number of keys to be inserted
#define NUM_KEYS 50

// Define the size of the hash tables
#define TABLE_SIZE 7

// Define a struct for the keys
struct Key {
    int value;
    struct Key* next;
};

// Define a hash table struct
struct HashTable {
    int size;
    struct Key** table;
};

// Hash function (can be changed for different hash functions)
int hash(int key, int size) {
    return key % size;
}

// Create a new hash table
struct HashTable* createHashTable(int size) {
    struct HashTable* table = (struct HashTable*)malloc(sizeof(struct HashTable));
    table->size = size;
    table->table = (struct Key**)malloc(sizeof(struct Key*) * size);
    for (int i = 0; i < size; i++) {
        table->table[i] = NULL;
    }
    return table;
}

// Insert a key into the hash table
void insert(struct HashTable* table, int key) {
    int index = hash(key, table->size);
    struct Key* newKey = (struct Key*)malloc(sizeof(struct Key));
    newKey->value = key;
    newKey->next = NULL;

    if (table->table[index] == NULL) {
        table->table[index] = newKey;
    } else {
        struct Key* current = table->table[index];
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newKey;
    }
}

// Print the hash table
void print(struct HashTable* table) {
    int longestChain = 0;
    int totalChainLength = 0;

    for (int i = 0; i < table->size; i++) {
        struct Key* current = table->table[i];
        int chainLength = 0;
        printf("Table[%d]: ", i);
        while (current != NULL) {
            printf("%d -> ", current->value);
            current = current->next;
            chainLength++;
        }
        printf("NULL\n");

        if (chainLength > longestChain) {
            longestChain = chainLength;
        }
        totalChainLength += chainLength;
    }

    printf("Longest chain: %d\n", longestChain);
    if (totalChainLength > 0) {
        printf("Average chain length: %lf\n", (double)totalChainLength / table->size);
    }
}

// Free the memory used by the hash table
void freeHashTable(struct HashTable* table) {
    for (int i = 0; i < table->size; i++) {
        struct Key* current = table->table[i];
        while (current != NULL) {
            struct Key* temp = current;
            current = current->next;
            free(temp);
        }
    }
    free(table->table);
    free(table);
}

int main() {
    // Initialize random number generator
    srand(time(NULL));

    // Create a hash table
    struct HashTable* table = createHashTable(TABLE_SIZE);

    // Insert random keys into the hash table
    for (int i = 0; i < NUM_KEYS; i++) {
        int key = rand() % 500;
        insert(table, key);
    }

    // Print the table
    print(table);

    // Free the memory used by the table
    freeHashTable(table);

    return 0;
}
