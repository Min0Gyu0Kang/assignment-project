#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define TABLE_SIZE 43
#define NUM_KEYS 30

// Define the hash table structure
typedef struct {
    int size;
    int *table;
    int probes;
    int maxClusterLength;
} HashTable;

int linearProbing(HashTable *hashTable, int key, int i) {
    return (key % hashTable->size + i) % hashTable->size;
}

int quadraticProbing(HashTable *hashTable, int key, int i) {
    return (key % hashTable->size + i + i * i) % hashTable->size;
}

int doubleHashing(HashTable *hashTable, int key, int i) {
    return (key % hashTable->size + i * (1 + (key % (hashTable->size - 1)))) % hashTable->size;
}

void insert(HashTable *hashTable, int key, int (*probingFunction)(HashTable *, int, int)) {
    int i = 0;
    while (i < hashTable->size) {
        int index = probingFunction(hashTable, key, i);
        hashTable->probes++;
        if (hashTable->table[index] == -1) {
            hashTable->table[index] = key;
            break;
        }
        i++;
    }
}

void print(HashTable *hashTable) {
    int averageProbes = hashTable->probes / NUM_KEYS;
    printf("Table Content:\n");
    for (int i = 0; i < hashTable->size; i++) {
        printf("Table[%d] = %d\n", i, hashTable->table[i]);
    }
    printf("Average Probes per Insertion: %d\n", averageProbes);
    printf("Primary Cluster Length: %d\n", calculatePrimaryClusterLength(hashTable));
}

int calculatePrimaryClusterLength(HashTable *hashTable) {
    int clusterLength = 0;
    hashTable->maxClusterLength = 0;
    int currentClusterLength = 0;
    for (int i = 0; i < hashTable->size; i++) {
        if (hashTable->table[i] != -1) {
            clusterLength++;
            currentClusterLength++;
            if (currentClusterLength > hashTable->maxClusterLength) {
                hashTable->maxClusterLength = currentClusterLength;
            }
        } else {
            currentClusterLength = 0;
        }
    }
    return clusterLength - hashTable->maxClusterLength;
}

int main() {
    // Initialize random number generator
    srand(time(NULL));

    // Create three hash tables using different probing methods
    HashTable linearProbingTable = {TABLE_SIZE, (int*)malloc(TABLE_SIZE * sizeof(int)), 0, 0};
    HashTable quadraticProbingTable = {TABLE_SIZE, (int*)malloc(TABLE_SIZE * sizeof(int)), 0, 0};
    HashTable doubleHashingTable = {TABLE_SIZE, (int*)malloc(TABLE_SIZE * sizeof(int)), 0, 0};

    for (int i = 0; i < TABLE_SIZE; i++) {
        linearProbingTable.table[i] = -1;
        quadraticProbingTable.table[i] = -1;
        doubleHashingTable.table[i] = -1;
    }

    // Insert 30 randomly generated keys into each table
    for (int i = 0; i < NUM_KEYS; i++) {
        int key = rand() % 500;
        insert(&linearProbingTable, key, linearProbing);
        insert(&quadraticProbingTable, key, quadraticProbing);
        insert(&doubleHashingTable, key, doubleHashing);
    }

    // Print the contents of the hash tables and calculate probe statistics
    printf("Linear Probing Hash Table:\n");
    print(&linearProbingTable);
    printf("\n");

    printf("Quadratic Probing Hash Table:\n");
    print(&quadraticProbingTable);
    printf("\n");

    printf("Double Hashing Hash Table:\n");
    print(&doubleHashingTable);

    // Free allocated memory
    free(linearProbingTable.table);
    free(quadraticProbingTable.table);
    free(doubleHashingTable.table);

    return 0;
}
