#include <stdio.h>
#include <stdlib.h>
#include <time.h>

enum Color { RED, BLACK };

struct Node {
    int key;
    enum Color color;
    struct Node* parent;
    struct Node* left;
    struct Node* right;
};

struct RedBlackTree {
    struct Node* root;
    struct Node* nil;
    int leftRotations;
    int rightRotations;
};

struct Node* createNode(int key, enum Color color, struct Node* parent, struct Node* left, struct Node* right) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    if (newNode == NULL) {
        exit(1);  // Error in memory allocation
    }
    newNode->key = key;
    newNode->color = color;
    newNode->parent = parent;
    newNode->left = left;
    newNode->right = right;
    return newNode;
}

struct RedBlackTree* createRedBlackTree() {
    struct RedBlackTree* rbt = (struct RedBlackTree*)malloc(sizeof(struct RedBlackTree));
    if (rbt == NULL) {
        exit(1);  // Error in memory allocation
    }
    rbt->nil = createNode(0, BLACK, NULL, NULL, NULL);
    rbt->root = rbt->nil;
    rbt->leftRotations = 0;
    rbt->rightRotations = 0;
    return rbt;
}

void leftRotate(struct RedBlackTree* rbt, struct Node* x) {
    struct Node* y = x->right;
    x->right = y->left;
    if (y->left != rbt->nil) {
        y->left->parent = x;
    }
    y->parent = x->parent;
    if (x->parent == rbt->nil) {
        rbt->root = y;
    } else if (x == x->parent->left) {
        x->parent->left = y;
    } else {
        x->parent->right = y;
    }
    y->left = x;
    x->parent = y;
    rbt->leftRotations++;
}

void rightRotate(struct RedBlackTree* rbt, struct Node* y) {
    struct Node* x = y->left;
    y->left = x->right;
    if (x->right != rbt->nil) {
        x->right->parent = y;
    }
    x->parent = y->parent;
    if (y->parent == rbt->nil) {
        rbt->root = x;
    } else if (y == y->parent->left) {
        y->parent->left = x;
    } else {
        y->parent->right = x;
    }
    x->right = y;
    y->parent = x;
    rbt->rightRotations++;
}

void insertFixup(struct RedBlackTree* rbt, struct Node* z) {
    while (z->parent->color == RED) {
        if (z->parent == z->parent->parent->left) {
            struct Node* y = z->parent->parent->right;
            if (y->color == RED) {
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->right) {
                    z = z->parent;
                    leftRotate(rbt, z);
                }
                z->parent->color = BLACK;
                z->parent->parent->color = RED;
                rightRotate(rbt, z->parent->parent);
            }
        } else {
            struct Node* y = z->parent->parent->left;
            if (y->color == RED) {
                z->parent->color = BLACK;
                y->color = BLACK;
                z->parent->parent->color = RED;
                z = z->parent->parent;
            } else {
                if (z == z->parent->left) {
                    z = z->parent;
                    rightRotate(rbt, z);
                }
                z->parent->color = BLACK;
                z->parent->parent->color = RED;
                leftRotate(rbt, z->parent->parent);
            }
        }
    }
    rbt->root->color = BLACK;
}
struct Node* search(struct RedBlackTree* rbt, struct Node* node, int key);

void insert(struct RedBlackTree* rbt, int key) {
    struct Node* z = createNode(key, RED, rbt->nil, rbt->nil, rbt->nil);
    struct Node* y = rbt->nil;
    struct Node* x = rbt->root;

    while (x != rbt->nil) {
        y = x;
        if (z->key < x->key) {
            x = x->left;
        } else if (z->key > x->key) {
            x = x->right;
        } else {
            // Duplicate key, ignore insertion
            free(z);
            return;
        }
    }

    z->parent = y;
    if (y == rbt->nil) {
        rbt->root = z;
    } else if (z->key < y->key) {
        y->left = z;
    } else {
        y->right = z;
    }

    insertFixup(rbt, z);
}

void transplant(struct RedBlackTree* rbt, struct Node* u, struct Node* v) {
    if (u->parent == rbt->nil) {
        rbt->root = v;
    } else if (u == u->parent->left) {
        u->parent->left = v;
    } else {
        u->parent->right = v;
    }
    v->parent = u->parent;
}

struct Node* minimum(struct RedBlackTree* rbt, struct Node* node) {
    while (node->left != rbt->nil) {
        node = node->left;
    }
    return node;
}

void deleteFixup(struct RedBlackTree* rbt, struct Node* x) {
    while (x != rbt->root && x->color == BLACK) {
        if (x == x->parent->left) {
            struct Node* w = x->parent->right;
            if (w->color == RED) {
                w->color = BLACK;
                x->parent->color = RED;
                leftRotate(rbt, x->parent);
                w = x->parent->right;
            }
            if (w->left->color == BLACK && w->right->color == BLACK) {
                w->color = RED;
                x = x->parent;
            } else {
                if (w->right->color == BLACK) {
                    w->left->color = BLACK;
                    w->color = RED;
                    rightRotate(rbt, w);
                    w = x->parent->right;
                }
                w->color = x->parent->color;
                x->parent->color = BLACK;
                w->right->color = BLACK;
                leftRotate(rbt, x->parent);
                x = rbt->root;
            }
        } else {
            struct Node* w = x->parent->left;
            if (w->color == RED) {
                w->color = BLACK;
                x->parent->color = RED;
                rightRotate(rbt, x->parent);
                w = x->parent->left;
            }
            if (w->right->color == BLACK && w->left->color == BLACK) {
                w->color = RED;
                x = x->parent;
            } else {
                if (w->left->color == BLACK) {
                    w->right->color = BLACK;
                    w->color = RED;
                    leftRotate(rbt, w);
                    w = x->parent->left;
                }
                w->color = x->parent->color;
                x->parent->color = BLACK;
                w->left->color = BLACK;
                rightRotate(rbt, x->parent);
                x = rbt->root;
            }
        }
    }
    x->color = BLACK;
}

void deleteNode(struct RedBlackTree* rbt, int key) {
    struct Node* z = search(rbt, rbt->root, key);
    if (z == rbt->nil) {
        // Key not found, ignore deletion
        return;
    }

    struct Node* y = z;
    enum Color yOriginalColor = y->color;
    struct Node* x;

    if (z->left == rbt->nil) {
        x = z->right;
        transplant(rbt, z, z->right);
    } else if (z->right == rbt->nil) {
        x = z->left;
        transplant(rbt, z, z->left);
    } else {
        y = minimum(rbt, z->right);
        yOriginalColor = y->color;
        x = y->right;
        if (y->parent == z) {
            x->parent = y;
        } else {
            transplant(rbt, y, y->right);
            y->right = z->right;
            y->right->parent = y;
        }
        transplant(rbt, z, y);
        y->left = z->left;
        y->left->parent = y;
        y->color = z->color;
    }

    free(z);

    if (yOriginalColor == BLACK) {
        deleteFixup(rbt, x);
    }
}

struct Node* search(struct RedBlackTree* rbt, struct Node* node, int key) {
    if (node == rbt->nil || node->key == key) {
        return node;
    }
    if (key < node->key) {
        return search(rbt, node->left, key);
    } else {
        return search(rbt, node->right, key);
    }
}

void printBST(struct RedBlackTree* rbt, struct Node* node, int depth) {
    if (node == rbt->nil) {
        return;
    }
    printBST(rbt, node->right, depth + 1);
    for (int i = 0; i < depth; i++) {
        printf("   ");
    }
    if (node->color == RED) {
        printf("%d (R)\n", node->key);
    } else {
        printf("%d (B)\n", node->key);
    }
    printBST(rbt, node->left, depth + 1);
}

int main() {
    srand(time(NULL));

    struct RedBlackTree* rbt = createRedBlackTree();
    int keys[] = {33, 17, 50, 22, 35, 41, 13, 38, 2, 16};

    for (int i = 0; i < 10; i++) {
        insert(rbt, keys[i]);
    }

    printf("Red-Black Tree after initial insertions:\n");
    printBST(rbt, rbt->root, 0);

    insert(rbt, 17);
    insert(rbt, 22);
    insert(rbt, 2);
    insert(rbt, 38);
    insert(rbt, 16);

    printf("Red-Black Tree after additional insertions:\n");
    printBST(rbt, rbt->root, 0);
    printf("Left Rotations: %d\n", rbt->leftRotations);
    printf("Right Rotations: %d\n", rbt->rightRotations);

    deleteNode(rbt, 17);
    deleteNode(rbt, rbt->root->key);
    deleteNode(rbt, 38);
    deleteNode(rbt, rbt->root->key);
    deleteNode(rbt, rbt->root->key);

    printf("Red-Black Tree after deletions:\n");
    printBST(rbt, rbt->root, 0);
    printf("Left Rotations: %d\n", rbt->leftRotations);
    printf("Right Rotations: %d\n", rbt->rightRotations);

    free(rbt->nil);
    free(rbt);

    return 0;
}
