import java.util.Random;

public class Ghost extends GameObject {
	Random rand = new Random();
	final private char icon = 'G';
	private int blockIdx; //24 x 24 y block coordinates from Game
	
	public char getIcon() {
		return icon;
	}
	public char removeIcon() {
		return ' ';
	}

	public int getBlockIdx() {
		getX();
		getY();
		return blockIdx;
	}

	public void setBlockIdx(int blockIdx) {
		this.blockIdx = blockIdx;
		setX(blockIdx);
		setY(blockIdx);
	}
	
}
