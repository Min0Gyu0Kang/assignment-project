
public class Block extends GameObject{
	final private char icon = '■';
	private int blockIdx;
	
	public char getIcon() {
		return icon;
	}

	public int getBlockIdx() {
		return blockIdx;
	}
 
	public void setBlockIdx(int blockIdx) {
		this.blockIdx = blockIdx;
	}
}
