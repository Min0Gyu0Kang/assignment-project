import java.util.Random;

public class Board implements Game{
	char[][] board;
	Block[] blocks;
	boolean isVictory=false;
	boolean hasKey=false;
	Random rand = new Random();
	Door d = new Door();
	Key k = new Key();
	Ghost g = new Ghost();
	Player p = new Player();
	
	Board(){
	}
	void resetBoard() {
		board = new char[][] {
			{ '■', '■', '■', '■', '■', '■','■','■','■','■', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', ' ',' ',' ',' ',' ', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', ' ','■','N','■',' ', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', ' ','■','#','■',' ', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', ' ','■','#','■',' ', '■', '■', '■', '■', '■'},
			{ '■', ' ', ' ', ' ', ' ', ' ','#','#','#',' ', ' ', ' ', ' ', ' ', '■'},
			{ '■', ' ', '■', '■', '■', '#','-','-','-','#', '■', '■', '■', ' ', '■'},
			{ '■', ' ', 'W', '#', '#', '#','-','-','-','#', '#', '#', 'E', ' ', '■'},
			{ '■', ' ', '■', '■', '■', '#','-','-','-','#', '■', '■', '■', ' ', '■'},
			{ '■', ' ', ' ', ' ', ' ', ' ','#','#','#',' ', ' ', ' ', ' ', ' ', '■'},
			{ '■', '■', '■', '■', '■', ' ','■','#','■',' ', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', ' ','■','#','■',' ', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', ' ','■','S','■',' ', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', ' ',' ',' ',' ',' ', '■', '■', '■', '■', '■'},
			{ '■', '■', '■', '■', '■', '■','■','■','■','■', '■', '■', '■', '■', '■'}
		};

	}
	// print current board
	public void printBoard() {
		
		for (int i = 0; i < 15; i++) { //row
			for (int j = 0; j < 15; j++) { //column
				System.out.print(this.board[i][j]);
			}
			System.out.println();
		}
		
	}
	
	// initialize objects -> door, key, ghost, player
	public void initObjects(){
		resetBoard();
		//4 coords door
		d.setBlockIdx(rand.nextInt(3)+1);
		board[Game.door_xCoords[d.getBlockIdx()]][Game.door_yCoords[d.getBlockIdx()]] =d.getIcon() ;
			
		//24 coords block
		k.setBlockIdx(rand.nextInt(23)+1);
		board[Game.block_xCoords[k.getBlockIdx()]][Game.block_yCoords[k.getBlockIdx()]]=k.getIcon();
			
		
		//24 coords block
		g.setBlockIdx(rand.nextInt(23)+1);
		board[Game.block_xCoords[g.getBlockIdx()]][Game.block_yCoords[g.getBlockIdx()]]=g.getIcon();
		
		//4 coords playerinit
		p.setBlockIdx(rand.nextInt(3)+1);
//		int pindex = Game.playerInit_blockIdx[p.getBlockIdx()];
		board[Game.playerInit_xCoords[p.getBlockIdx()]][Game.playerInit_yCoords[p.getBlockIdx()]]=p.getIcon();
			
	}
	// move player to the new location of the board
	public void movePlayer(int moves) {
		//p moves 3 spaces
		int x = Game.block_xCoords[p.getBlockIdx()];
		int y = Game.block_yCoords[p.getBlockIdx()];
		board[Game.playerInit_xCoords[p.getBlockIdx()]][Game.playerInit_yCoords[p.getBlockIdx()]]=p.removeIcon();
		board[x][y] =p.removeIcon();
		while(x>=1&&x<=13&&y>=1&&y<=13) {
			int move = rand.nextInt(8);
			if(move==0&&x+moves<=13) {//+0
				board[x][y] = board[x+moves][y];
				break;
			}
			else if (move==1&&x-moves>=1) {//-0
				board[x][y] = board[x-moves][y];
				break;
			}
			else if (move==2&&x+moves<=13&&y+moves<=13) {//++
				board[x][y] = board[x+moves][y+moves];
				break;
			}
			else if(move ==3&&x-moves>=1&&y-moves>=1){//--
				board[x][y] = board[x-moves][y-moves];
				break;
			}
			else if (move==4&&y-moves>=1) {//0-
				board[x][y] = board[x][y-moves];
				break;
			}
			else if (move==5&&x-moves>=1) {//-0
				board[x][y] = board[x-moves][y];
				break;
			}
			else if(move ==6&&x+moves<=13&&y-moves>=1){//+-
				board[x][y] = board[x+moves][y-moves];
				break;
			}
			else {//7 //-+
				board[x][y] = board[x][y];
				break;
			}
				
		}
		board[x][y]=p.getIcon();
		//do not walk through walls beyond blocks x(1~13) y(1~13)

		
	}	
	// move ghost to the new location of the board
	public void moveGhost(int moves){
		//g moves 9 spaces
		int x=Game.block_xCoords[g.getBlockIdx()];
		int y=Game.block_yCoords[g.getBlockIdx()];
		while(x>=1&&x<=13&&y>=1&&y<=13) {
			int move = rand.nextInt(8);
			if(move==0&&x+moves<=13) {//+0
				board[x][y] = board[x+moves][y];
				break;
			}
			else if (move==1&&x-moves>=1) {//-0
				board[x][y] = board[x-moves][y];
				break;
			}
			else if (move==2&&x+moves<=13&&y+moves<=13) {//++
				board[x][y] = board[x+moves][y+moves];
				break;
			}
			else if(move ==3&&x-moves>=1&&y-moves>=1){//--
				board[x][y] = board[x-moves][y-moves];
				break;
			}
			else if (move==4&&y-moves>=1) {//0-
				board[x][y] = board[x][y-moves];
				break;
			}
			else if (move==5&&x-moves>=1) {//-0
				board[x][y] = board[x-moves][y];
				break;
			}
			else if(move ==6&&x+moves<=13&&y-moves>=1){//+-
				board[x][y] = board[x+moves][y-moves];
				break;
			}
			else {//7 //-+
				board[x][y] = board[x][y];
				break;
			}

		}
		board[x][y]=g.getIcon();
	}

	
	// invoke whether the game is finished or not
	public boolean isFinished() {
	//If player arrive at door with key, move player to the door, and player wins.
		if(board[Game.block_xCoords[p.getBlockIdx()]][Game.block_yCoords[p.getBlockIdx()]]==board[Game.block_xCoords[k.getBlockIdx()]][Game.block_yCoords[k.getBlockIdx()]]) {
		//player arrive at key	
			hasKey=true;
			board[Game.block_xCoords[k.getBlockIdx()]][Game.block_yCoords[k.getBlockIdx()]] = k.removeIcon(); //remove key
			if(hasKey&&board[Game.block_xCoords[p.getBlockIdx()]][Game.block_yCoords[p.getBlockIdx()]]==board[Game.door_xCoords[d.getBlockIdx()]][Game.door_yCoords[d.getBlockIdx()]]) {
			//player arrive at door with key
				isVictory = true;
				return isVictory;
			}
			else {
				return isVictory;
			}
		}
	//If ghost catch the player, player loses.
		else if (board[Game.block_xCoords[p.getBlockIdx()]][Game.block_yCoords[p.getBlockIdx()]]==board[Game.block_xCoords[g.getBlockIdx()]][Game.block_yCoords[g.getBlockIdx()]]) {
		//player arrive at ghost
			return isVictory;
		}
		return isVictory;
	}
}
