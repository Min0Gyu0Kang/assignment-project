import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
    public static void main(String[] args) {
        try {
            ServerSocket serverSocket = new ServerSocket(15118); // Choose a suitable port number
            
            System.out.println("Waiting for Client...");
            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Client connected. ");
                
                BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                
                String message;
                while ((message = in.readLine()) != null) {
                    System.out.println(message); //"Received message from client: " 
                    
                    if (message.equalsIgnoreCase("Exit")) {
                        break;
                    }
                    
                    double result = performCalculation(message);
                    out.println(result);
                    System.out.println(result);//"Sent result to client: "
                }
                System.out.println("Client disconnected. ");
                clientSocket.close();
                System.exit(0);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    private static double performCalculation(String message) {
        // Parse the message and perform the calculation
        String[] parts = message.split(" "); // Split on whitespace
        double num1 = Double.parseDouble(parts[0]);
        double num2 = Double.parseDouble(parts[2]);
        String operator = parts[1];
        double result = 0;
        switch (operator) {
            case "+":
                result = num1 + num2;
                break;
            case "-":
                result = num1 - num2;
                break;
            case "*":
                result = num1 * num2;
                break;
            case "/":
                result = num1 / num2;
                break;
            default:
                System.out.println("Invalid operator");
        }
        
        return result;
    }
}
