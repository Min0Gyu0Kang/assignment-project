#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Function to allocate memory for a matrix
int** allocateMatrix(int rows, int cols) {
    int** matrix = (int**)malloc(rows * sizeof(int*));
    for (int i = 0; i < rows; i++) {
        matrix[i] = (int*)malloc(cols * sizeof(int));
    }
    return matrix;
}

// Function to generate random values for a matrix
void fillRandomMatrix(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            matrix[i][j] = rand() % 1000;
        }
    }
}

// Function to deallocate memory for a matrix
void freeMatrix(int** matrix, int rows) {
    for (int i = 0; i < rows; i++) {
        free(matrix[i]);
    }
    free(matrix);
}

// Function to print a matrix
void printMatrix(int** matrix, int rows, int cols) {
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d ", matrix[i][j]);
        }
        printf("\n");
    }
}

// Function to perform matrix multiplication using the standard algorithm
void standardMatrixMultiplication(int** A, int** B, int** C, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            C[i][j] = 0;
            for (int k = 0; k < n; k++) {
                C[i][j] += A[i][k] * B[k][j];
            }
        }
    }
}

// Function to perform matrix multiplication using the divide-and-conquer algorithm
void divideAndConquerMatrixMultiplication(int** A, int** B, int** C, int n, int A_row, int A_col, int B_row, int B_col) {
    if (n == 1) {
        C[A_row][B_col] += A[A_row][A_col] * B[B_row][B_col];
        return;
    }

    int newSize = n / 2;

    // Compute C11
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row, A_col, B_row, B_col);
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row, A_col + newSize, B_row + newSize, B_col);

    // Compute C12
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row, A_col, B_row, B_col + newSize);
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row, A_col + newSize, B_row + newSize, B_col);

    // Compute C21
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row + newSize, A_col, B_row, B_col);
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row + newSize, A_col + newSize, B_row + newSize, B_col);

    // Compute C22
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row + newSize, A_col, B_row, B_col + newSize);
    divideAndConquerMatrixMultiplication(A, B, C, newSize, A_row + newSize, A_col + newSize, B_row + newSize, B_col);
}

int main() {
    srand(time(NULL));

    int n4x4 = 4;
    int n8x8 = 8;

    // Allocate memory for matrices A, B, and C for 4x4 multiplication
    int** A4x4 = allocateMatrix(n4x4, n4x4);
    int** B4x4 = allocateMatrix(n4x4, n4x4);
    int** C4x4 = allocateMatrix(n4x4, n4x4);

    // Fill matrices A and B with random values for 4x4 multiplication
    fillRandomMatrix(A4x4, n4x4, n4x4);
    fillRandomMatrix(B4x4, n4x4, n4x4);

    // Perform standard matrix multiplication for 4x4 matrices
    standardMatrixMultiplication(A4x4, B4x4, C4x4, n4x4);

    printf("Matrix A (4x4):\n");
    printMatrix(A4x4, n4x4, n4x4);
    printf("\nMatrix B (4x4):\n");
    printMatrix(B4x4, n4x4, n4x4);
    printf("\nMatrix C (4x4) - Standard Multiplication:\n");
    printMatrix(C4x4, n4x4, n4x4);

    // Free memory for matrices A, B, and C for 4x4 multiplication
    freeMatrix(A4x4, n4x4);
    freeMatrix(B4x4, n4x4);
    freeMatrix(C4x4, n4x4);

    // Allocate memory for matrices A, B, and C for 8x8 multiplication
    int** A8x8 = allocateMatrix(n8x8, n8x8);
    int** B8x8 = allocateMatrix(n8x8, n8x8);
    int** C8x8 = allocateMatrix(n8x8, n8x8);

    // Fill matrices A and B with random values for 8x8 multiplication
    fillRandomMatrix(A8x8, n8x8, n8x8);
    fillRandomMatrix(B8x8, n8x8, n8x8);

    // Perform divide-and-conquer matrix multiplication for 8x8 matrices
    printf("\nPerforming Divide-and-Conquer Multiplication for 8x8 Matrices:\n");
    divideAndConquerMatrixMultiplication(A8x8, B8x8, C8x8, n8x8, 0, 0, 0, 0);

    printf("\nMatrix A (8x8):\n");
    printMatrix(A8x8, n8x8, n8x8);
    printf("\nMatrix B (8x8):\n");
    printMatrix(B8x8, n8x8, n8x8);
    printf("\nMatrix C (8x8) - Divide-and-Conquer Multiplication:\n");
    printMatrix(C8x8, n8x8, n8x8);

    // Free memory for matrices A, B, and C for 8x8 multiplication
    freeMatrix(A8x8, n8x8);
    freeMatrix(B8x8, n8x8);
    freeMatrix(C8x8, n8x8);

    return 0;
}
