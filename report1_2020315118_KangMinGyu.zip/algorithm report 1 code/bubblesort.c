#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Function to perform the Bubble Sort
int bubbleSort(int A[], int n) {
    int operations = 0;
    int swapped;

    for (int i = 0; i < n - 1; i++) {
        swapped = 0;

        for (int j = 0; j < n - i - 1; j++) {
            // Compare adjacent elements and swap if they are in the wrong order
            if (A[j] > A[j + 1]) {
                int temp = A[j];
                A[j] = A[j + 1];
                A[j + 1] = temp;
                swapped = 1;
            }

            operations++; // Increment the operation count
        }

        // If no two elements were swapped in the inner loop, the array is already sorted
        if (swapped == 0) {
            break;
        }
    }

    return operations;
}

// Function to print an array
void printArray(int A[], int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", A[i]);
    }
    printf("\n");
}

int main() {
    srand(time(NULL));

    int A1[100], A2[100], A3[100];
    int n = 100;

    // Generate random integers for A1
    for (int i = 0; i < n; i++) {
        A1[i] = rand() % 1000;
    }

    // Generate almost sorted A2
    for (int i = 0; i < n; i++) {
        A2[i] = i + 1;
    }
    // Introduce 5 incorrect orderings
    A2[10] = 15;
    A2[20] = 5;
    A2[30] = 25;
    A2[40] = 35;
    A2[50] = 45;

    // Generate almost reversely sorted A3
    for (int i = 0; i < n; i++) {
        A3[i] = n - i;
    }
    // Introduce 5 incorrect orderings
    A3[10] = 95;
    A3[20] = 85;
    A3[30] = 75;
    A3[40] = 65;
    A3[50] = 55;

    printf("Original A1: ");
    printArray(A1, n);
    int ops1 = bubbleSort(A1, n);
    printf("Sorted A1: ");
    printArray(A1, n);
    printf("Operations for A1: %d\n\n", ops1);

    printf("Original A2: ");
    printArray(A2, n);
    int ops2 = bubbleSort(A2, n);
    printf("Sorted A2: ");
    printArray(A2, n);
    printf("Operations for A2: %d\n\n", ops2);

    printf("Original A3: ");
    printArray(A3, n);
    int ops3 = bubbleSort(A3, n);
    printf("Sorted A3: ");
    printArray(A3, n);
    printf("Operations for A3: %d\n\n", ops3);

    return 0;
}
