#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// Define a structure for a linked list node
struct Node {
    int data;
    struct Node* next;
};

// Function to create a new node with given data
struct Node* createNode(int data) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Function to insert an integer x immediately after the first largest element in the linked list
void insert(struct Node** head, int x) {
    struct Node* newNode = createNode(x);

    if (*head == NULL || x >= (*head)->data) {
        newNode->next = *head;
        *head = newNode;
        return;
    }

    struct Node* current = *head;
    while (current->next != NULL && current->next->data > x) {
        current = current->next;
    }

    newNode->next = current->next;
    current->next = newNode;
}

// Function to delete the first largest integer in the linked list
void delete(struct Node** head) {
    if (*head == NULL) {
        return; // List is empty
    }

    struct Node* current = *head;
    struct Node* prev = NULL;
    int max = (*head)->data;

    while (current->next != NULL) {
        if (current->next->data > max) {
            max = current->next->data;
            prev = current;
        }
        current = current->next;
    }

    if (prev == NULL) {
        // The first element is the largest
        struct Node* temp = *head;
        *head = (*head)->next;
        free(temp);
    } else {
        struct Node* temp = prev->next;
        prev->next = temp->next;
        free(temp);
    }
}

// Function to print the content of a linked list in two lines
void print(struct Node* head) {
    struct Node* current = head;
    int count = 0;

    // Count the number of elements in the list
    while (current != NULL) {
        count++;
        current = current->next;
    }

    current = head;
    int i = 0;

    printf("1st line: ");
    while (i < count / 2) {
        printf("%d ", current->data);
        current = current->next;
        i++;
    }
    printf("\n");

    printf("2nd line: ");
    while (current != NULL) {
        printf("%d ", current->data);
        current = current->next;
    }
    printf("\n");
}

int main() {
    srand(time(NULL));

    struct Node* head = NULL;

    // Insert 50 random integers into the linked list
    for (int i = 0; i < 50; i++) {
        int x = rand() % 1000;
        insert(&head, x);
    }

    // Delete the largest element and print the list for 4 iterations
    for (int i = 0; i < 4; i++) {
        delete(&head);
        printf("Iteration %d:\n", i + 1);
        print(head);
    }

    return 0;
}
