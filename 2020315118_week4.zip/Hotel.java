import java.util.Random;
import java.util.Scanner;

class Room{
	Random random;
	public Room() {
	random = new Random();
	this.capacity = random.nextInt(4)+1;
	this.Occupied = false;
	//System.out.print(this.capacity+" ");
	}
	Boolean Occupied;
	int capacity;
}

public class Hotel {
		
	void checkin(int n, int j, Room[] r){
		if(r[n-1].Occupied == true) {
			System.out.println("Already check in!");
		}
		else if(r[n-1].capacity >= j) {
			System.out.println("Check in Finish");
			r[n-1].Occupied = true;
		}
		else {
			System.out.println("Too many people!");
		}
		
	}//nth room, jth people
	void checkout(int n , Room[] r){
		if(r[n-1].Occupied == true   ) { 
			System.out.println("Check out Finish");
			r[n-1].Occupied = false;
		}
		else {
			System.out.println("Already check out!");
		}
			
	}


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scn = new Scanner(System.in);
		Room[] r = new Room[10]; 
		Hotel h = new Hotel(); 

		System.out.println("Each Room's Capacity");
		for(int i = 0; i<10;i++) {
			r[i] = new Room();
			System.out.print(r[i].capacity+" ");
		}
		System.out.println();
		while (true) {
			System.out.println("Enter number (1 : check in)(2 : check out)(3 : Finish)");
			int num = scn.nextInt();
			if(num==1||num==2) {
				System.out.println("Enter room number");
				int room = scn.nextInt();
				if(num==1) {
					System.out.println("How many people?");
					int people = scn.nextInt();
					h.checkin(room,people,r);
				}
				if(num==2) {
					h.checkout(room,r);
				}
				
			}
			if(num==3) {
				break;
			}
		}

	}

}