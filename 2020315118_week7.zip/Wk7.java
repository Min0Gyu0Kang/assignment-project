import java.util.*;

class Product{
	String name;
	int price=0;	
}

public class Wk7 extends Product{
	Product p = new Product();
	void add(String n){
		ArrayList<String> list = new ArrayList<>();
		HashMap<String, Integer> map = new HashMap<>();
		String [] give = n.split("");
		String na=give[0];
		String pr=give[1];
		Integer pri = Integer.valueOf(pr);
		if(give.length < 3){
			if(give.length >=1 && give.length == 2) {
				if(!na.equals(p.name)) {
					if(pri!=p.price) {
						map.put(na,pri);
						System.out.println("Product-"+na+" Price-"+pri+"is added successfully");
					}
					else { //wrong price
						System.out.println("Invalid Format: Invalid price");
					}
				}
				else{//already there

					System.out.println("Already exist product");
					
				}
			}
			else{//less than 2 words
				System.out.println("Invalid Format: Missing required components");
			}
			
		}
		else{ //more than 2 words
			System.out.println("Invalid Format: There is more than two words");
		}
		
	}
	void delete(String p){
		ArrayList<String> list = new ArrayList<>();
		HashMap<String,Integer> map = new HashMap<>();
		String [] give = p.split("");
		String na=give[0];
		String pr=give[1];
		Integer pri = Integer.valueOf(pr);
		if(na.equals(p.name)) {
			if(give.length<2) {
				map.remove(na);	
				System.out.println("Product-"+na+" Price-"+pri+"is deleted successfully");
			}
			else {//more than words
				System.out.println("Invalid Format: There is not exist product");
			}
			
		}
		else {//already delete or not added
			System.out.println("Invalid Format: There is more than one words");
		}
	}
	void find(String p){
		String [] give = p.split("");
		String na=give[0];
		String pr=give[1];
		Integer pri = Integer.valueOf(pr);
		if(na.equals(p.name)) {
			System.out.println("Product-"+na+", Price-"+pri);
		}
		else {//not found
			System.out.println("Invalid Format: There is not exist product");
		}
	}
	@SuppressWarnings("unchecked")
	void show(){
		new ArrayList<>();
		HashMap<String, Integer> map = new HashMap<>();
		Iterator<String> iter = map.keySet().iterator();
		while (iter.hasNext()) {
			String key = iter.next();
			Integer value = map.get(key);
			System.out.println("Product-"+ key + ", Price-" + value);
		}
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scn = new Scanner(System.in);
		new ArrayList<>();
		HashMap<String, Integer> map = new HashMap<>();
		Iterator<String> iter = map.keySet().iterator();
		Product p = new Product();
		Wk7 f = new Wk7();
		
		while(true) {
			System.out.println("Enter number (1: add), (2: delete), (3: find),(4:show), (5:finish)");
			int num=scn.nextInt();
			scn.nextLine();
			if(num==1) {//add
				System.out.println("Enter product information to add");
				String a=scn.nextLine(); //includes product and price
				f.add(a);
			}
			else if(num==2){//delete
				System.out.println("Enter product information to delete");
				String b=scn.next(); //product
				f.delete(b);
			}
			else if(num==3) {//find
				System.out.println("Enter product name to find");
				String c=scn.next();
				f.find(c);
			}
			else if(num==4) {//show
				f.show();
			}
			else {//finish
				break;
			}
		
		}
	}

}
