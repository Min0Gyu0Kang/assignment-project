import java.util.HashMap;

public class VariableTable {
	HashMap<String, Double> varTable;
	
	VariableTable(){
		this.varTable = new HashMap<>();
	}
	
	// Check whether variable exists in the variable Table or not
	public boolean varExists(String varName) {
		return varTable.containsKey(varName);
	}
	
	// Get value of the given variable name
	public double getVarValue(String varName) {
		return varTable.get(varName);
	}
	
	// Register & update variable of the variable Table
	public void registerVar(String varName, double varValue) {
		varTable.put(varName, varValue);
	}
}
