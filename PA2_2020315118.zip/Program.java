import java.io.*;

public class Program {
	String filePath;
	Interpreter interpreter;
	Program(String filePath){
		this.filePath = filePath;
		this.interpreter = new Interpreter();
	}
	
	// Print out currently running instruction
	public void printInstruction(String instruction) {
		try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                System.out.println(line);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	// Run single instruction
	public boolean runInstruction(String instruction) {
		return interpreter.Interpret(instruction);
	}
	
	// Get result
	public double getResult() { //used in MiniCalc
		return this.interpreter.result;
	}
	
	// Run every instructions
	public boolean run() { //used in MiniCalc
		printInstruction(filePath);
		try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!runInstruction(line)) {
                    return false;
                }
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
	
}
