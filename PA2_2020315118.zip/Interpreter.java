import java.io.*;

public class Interpreter {
	VariableTable varTable;
	double result;
	String filePath;
	Interpreter(){
		this.varTable = new VariableTable();
	}
	
	// Execute one instruction line.
	public boolean Interpret(String instruction) {
		// Parse the instruction and perform the necessary operations
		String[] parts = instruction.split(" "); // Split the instruction based on a space delimiter
		String operand = parts[0];
        try {
        	switch(operand) {
        	case "Add":
        		double addResult = getValueOfToken(parts[1]) + getValueOfToken(parts[2]);
        		result = addResult;
        		varTable.registerVar(parts[3], result);
                break;
            case "Sub":
                double subResult = getValueOfToken(parts[1]) - getValueOfToken(parts[2]);
                result += subResult;
                varTable.registerVar(parts[3], result);
                break;
            case "Mul":
                double mulResult = getValueOfToken(parts[1]) * getValueOfToken(parts[2]);
                result += mulResult;
                varTable.registerVar(parts[3], result);
                break;
            case "Div":
                double divResult = getValueOfToken(parts[1]) / getValueOfToken(parts[2]);
                result += divResult;
                varTable.registerVar(parts[3], result);
                break;
            case "Execute":
            	String filePath = "./"+ parts[1] + ".txt";
            	boolean executionResult = executeInstructionsFromFile(filePath);
                if (!executionResult) {
                    return false;
                }
                break;
            case "Return":
                break;
            default:
//                System.out.println("Invalid command: " + command);
                return false;
        	}
    	    return true;
    	    
        }
	    catch(NumberFormatException e1) {
	    	System.out.println("Cannot store result into a number!"); 
	    	System.out.println("Program Failed!!!"); 
	    	return false;}
		catch(IllegalArgumentException e2) {
			System.out.println("Invalid Variable!"); 
	    	System.out.println("Program Failed!!!");
	    	return false;
	    	}
		}
	// Execute instructions from a file
    private boolean executeInstructionsFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
            	System.out.println(line);
                Interpret(line);
            }
            return true;
        } catch (IOException e) {
            System.out.println("Error executing instructions from file: " + filePath);
            e.printStackTrace();
            return false;
        }
    }
	// Check whether the variable token is valid (if it is in the HashMap or not).
	public boolean validToken(String token) {
		return varTable.varExists(token);
	}
	// Check whether the variable token is numeric or not.
	public boolean isNumeric(String token) {
		try {
	        Double.parseDouble(token);
	        return true;
	    } catch (NumberFormatException e) {
	        return false;
	    }
	}
	
	// Get value of the variable token from the Hashmap.
	public double getValueOfToken(String token) { 
		if (validToken(token)) {
	        return varTable.getVarValue(token);
	    }
	    return Double.parseDouble(token);
	}
}